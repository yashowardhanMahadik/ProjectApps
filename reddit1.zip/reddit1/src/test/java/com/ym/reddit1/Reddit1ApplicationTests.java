package com.ym.reddit1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reddit1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
